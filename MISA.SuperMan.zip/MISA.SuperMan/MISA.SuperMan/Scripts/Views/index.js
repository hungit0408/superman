﻿$(document).ready(function () {
    // Load dữ liệu:
    loadData();
    dialog = $('.dialogCustomerDetail').dialog({
        width: 600,
        height: 200,
        autoOpen: true,
        modal: true,
        buttons: [
            {
                text: 'Thêm',
                id: "btnAdd",
                manhnv: 'sdfjklashdfjiasdfhjkasfhdk',
                click: function () {
                    alert('hello');
                }
            },
            {
                text: 'Sửa',
                id:'btnEdit'
            },
            {
                text: 'Đóng',
                click: function () {
                    dialog.dialog('close');
                }
            },
        ]
    })
    // Gán Events:
    $('#btnAddCustomer').click(function () {
        dialog.dialog('open');
    })
})


function loadData() {
    fakeData();
    var rowHTML = $('<tr></tr>');
    $.each(data, function (index, item) {
        debugger;
        var cellHTML = '<tr><td>' + item["CustomerCode"] + '</td>' +
            '<td>' + item["CustomerName"] + '</td>' +
            '<td>' + item["CompanyName"] + '</td>' +
            '<td>' + item["TaxCode"] + '</td>' +
            '<td>' + item["Address"] + '</td>' +
            '<td>' + item["Mobile"] + '</td></tr>';
        //rowHTML = rowHTML.append(cellHTML);
        debugger;
        $('#listCustomer').append(cellHTML);
    });
}

data = [];
function fakeData() {
    for (var i = 0; i < 100; i++) {
        var customer = { CustomerCode: 'Kh000' + i, CustomerName: "Nguyễn Văn Mạnh", CompanyName: "công ty Cổ phần MISA", TaxCode: "0101201541", Address: "Duy Tân, Cầu Giấy, HN", Mobile: "0977340334" }
        data.push(customer);
    }
}
